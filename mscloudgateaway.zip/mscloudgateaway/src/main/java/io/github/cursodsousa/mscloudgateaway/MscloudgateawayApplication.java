package io.github.cursodsousa.mscloudgateaway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MscloudgateawayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MscloudgateawayApplication.class, args);
	}

}
