package io.github.cursodsousa.mscloudgateaway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MscloudgateawayApplicationTests {

	@Test
	void contextLoads() {
	}

}
