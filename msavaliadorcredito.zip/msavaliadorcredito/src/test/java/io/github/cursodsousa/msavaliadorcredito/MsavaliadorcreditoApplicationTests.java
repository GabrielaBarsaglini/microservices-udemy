package io.github.cursodsousa.msavaliadorcredito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsavaliadorcreditoApplicationTests {

	@Test
	void contextLoads() {
	}

}
